console.log("mensaje en la terminal");
console.log(5+7);