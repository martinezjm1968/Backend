const edad=20;
const nombre="Laura";
console.log("soy " + nombre + " y tengo " + edad + " años");

const calcularEdad = (edad)=>edad*2;

console.log(`soy ${nombre} y tengo ${calcularEdad(12)} años`);
