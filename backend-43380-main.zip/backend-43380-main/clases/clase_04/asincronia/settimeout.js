setTimeout(() => {
    console.log("ya transcurrio 5s");
}, 5000);

console.log("operacion1");
console.log("operacion2");
setTimeout(() => {
    console.log("operacion3 ya termino");
}, 3000);