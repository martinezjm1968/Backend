export class ToysMongo{
    constructor(){
        // this.model = toysModel;
    }

    get(){
        // return this.model.find();
    }
}