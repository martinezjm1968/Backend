// const result = Math.pow(5,2);

const result = 5**2;
console.log(result);
