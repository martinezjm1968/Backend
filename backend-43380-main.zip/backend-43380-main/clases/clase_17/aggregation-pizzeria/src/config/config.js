export const config = {
    server:{
        port:8080
    },
    mongo:{
        url:"url mongo"
    }
}