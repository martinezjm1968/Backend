export const config = {
    server:{
        port:8080
    },
    fileSystem:{
        productsFile:"products.json",
        cartFile:"carts.json"
    },
    mongo:{
        url:"URL MONGO"
    }
}