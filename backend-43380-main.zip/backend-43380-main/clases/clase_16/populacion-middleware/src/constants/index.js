export const studentCollection = "students";
export const courseCollection = "courses";