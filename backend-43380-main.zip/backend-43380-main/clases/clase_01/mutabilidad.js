//asignacion
// const numeros = [1,2,3];
// numeros = [1,2,3,4];

// let numeros = [1,2,3];
// numeros = [1,2,3,4];
// console.log(numeros);

//mutabilidad
const numeros2 = [1,2,3];
numeros2.push(4);
console.log(numeros2);

const persona = {
    nombre:"juan",
    edad:20
};
persona.edad=21;
console.log(persona);