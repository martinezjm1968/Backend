const sumar = (num1,num2)=>num1+num2;
const restar = (num1,num2)=>num1-num2;
const multiplicar = (num1,num2)=>num1*num2;
const dividir = (num1,num2)=>num1/num2;
const potencia = (base, exponente)=>base**exponente;

export {sumar,restar,multiplicar,dividir, potencia}