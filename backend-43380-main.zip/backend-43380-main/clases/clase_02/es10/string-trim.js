const correoFormulario = "    fredy@gmail.com       ";
const correoRegistro = correoFormulario.trim();
if(correoRegistro === "fredy@gmail.com"){
    console.log("iniciaste sesion")
} else {
    console.log("este correo no existe")
}