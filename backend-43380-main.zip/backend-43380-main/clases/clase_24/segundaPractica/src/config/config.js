export const config = {
    server:{
        port:8080,
        secretSession:"secretCoderSessions43380"
    },
    mongo:{
        url:"URL MONGO"
    }
}