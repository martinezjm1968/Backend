export const config = {
    secretToken:"coderSecretToken"
}