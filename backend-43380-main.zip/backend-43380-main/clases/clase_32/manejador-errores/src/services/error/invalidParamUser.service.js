export const invalidParamMsg = (userId)=>{
    return `El id del usuario no es valido, debe ser de tipo numerico, y se recibio ${userId}`
};