// es5
// var estudiante = "juan";
// var estudiante = "laura";
// var estudiante = "felipe";
// console.log(estudiante);

// es6 => let y const
//let no podemos re-declarar, pero si podemos reasignar.
let curso1 = "html";
let curso2 = "nodejs";
console.log(curso1);
console.log(curso2);
//con let reasignar
curso1="html2";
console.log(curso1);

//const no podemos redeclara, pero tampoco reasignar
const edad=20;
// edad=30;
console.log(edad);
