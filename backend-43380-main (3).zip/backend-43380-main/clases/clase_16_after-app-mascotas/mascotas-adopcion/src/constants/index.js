export const petsCollection = "pets";
export const usersCollection = "users";