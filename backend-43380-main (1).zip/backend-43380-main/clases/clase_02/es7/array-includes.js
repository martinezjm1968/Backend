const numeros = [1,2,3,4,5];

// const result = numeros.includes(2);
// console.log(result);

// const resultB = numeros.includes(6);
// console.log(resultB);

const usuarios = ["pablo","ana","juan"];
// const resultC = usuarios.includes("pepe");
// console.log(resultC);//output false

if(usuarios.includes("pablo")){
    console.log("tienes acceso");
} else {
    console.log("el usuario no existe");
}