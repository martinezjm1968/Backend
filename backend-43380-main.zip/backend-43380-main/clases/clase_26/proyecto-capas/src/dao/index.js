import { ToysMemory } from "./memory/ToysMemory.js";

export const toysDao = new ToysMemory();