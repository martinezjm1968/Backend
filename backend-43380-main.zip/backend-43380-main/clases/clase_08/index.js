//productos.json
{
    "id":1,
    "title":"producto1",
    "price":200,
    "description":"descripcion del producto",
    ...
}

//carritos
{
    "id":1,
    "products":[
        {
            "product":1,
            "quantity":2
        },
        {
            "product":4,
            "quantity":1
        }
    ]
}